const base = require('/Users/mm/Desktop/homecredit/cypress/support/page_object/page.js');

given('user create account account', () => {
    base.navigatToPage('live');
});

when('User fill firstname with {string}', (param) => {
    base.input(param);
});

then('User fill surname with {string}', (param) => {
    base.input(param);
});

then('User fill email or mobile number with {string}', (param) => {
    base.input(param);
});

then('User refill same email or number phone', () => {
    base.input('remail');
});

then('User fill password with {string}', (param) => {
    base.input(param);
});

when('User fill password with {string}', (param) => {
    base.input(param);
});
then('User fill date of birth and sex', () => {
    base.input('tgl');
    base.input('bln');
    base.input('thn');
    base.input('male');
    base.clickButton('clickLogin');
    // base.clickButton('clickLogin');
});